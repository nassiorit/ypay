import 'dart:io';


import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:notification_permissions/notification_permissions.dart';
import '../firebase_options.dart';
class FcmUtils {

  static final FcmUtils _singleton = new FcmUtils._internal();

  FcmUtils._internal();

  factory FcmUtils() {
    return _singleton;
  }

  late FirebaseMessaging messaging;

  /// Create a [AndroidNotificationChannel] for heads up notifications
  late AndroidNotificationChannel channel;

  /// Initialize the [FlutterLocalNotificationsPlugin] package.
  late FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin;

  Future initApp() async {
    print("init initializeApp");

    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );

    messaging = FirebaseMessaging.instance;

    if (!kIsWeb) {

      channel = const AndroidNotificationChannel(
        'high_importance_channel', // id
        'High Importance Notifications', // title
        importance: Importance.high,
      );

      flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();

      /// Create an Android Notification Channel.
      ///
      /// We use this channel in the `AndroidManifest.xml` file to override the
      /// default FCM channel to enable heads up notifications.
      ///
      print("init flutterLocalNotificationsPlugin");

      await flutterLocalNotificationsPlugin
          .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>()
          ?.createNotificationChannel(channel);

      print("init setForegroundNotificationPresentationOptions");


      //for IOS Foreground Notification
    await messaging.setForegroundNotificationPresentationOptions(
      alert: true,
      badge: true,
      sound: true,
    );

      print("init listen");


      FirebaseMessaging.instance.onTokenRefresh.listen((String token) async {
      print("New token: $token");
    });
  }
}

  Future subscripeToTopics(String topic) async {
    await messaging.subscribeToTopic(topic);
  }


  ///Expire : https://firebase.google.com/docs/cloud-messaging/manage-tokens
  Future<String?> getFCMToken() async {
    final fcmToken = await messaging.getToken();
    print("FCM Token ${fcmToken}");

    return fcmToken;
  }

  void tokenListener() {
    messaging.onTokenRefresh.listen((fcmToken) {
      print("FCM Token dinlemede");
      print("FCM Token ${fcmToken}");

      // TODO: If necessary send token to application server.
    }).onError((err) {
      print("FCM Token error");

      print(err);
    });
  }

  /// IOS
  Future iosWebPermission() async {
    if (Platform.isIOS) {
      NotificationSettings settings = await messaging.requestPermission(
        alert: true,
        announcement: false,
        badge: true,
        carPlay: false,
        criticalAlert: false,
        provisional: false,
        sound: true,
      );
    }
  }

  Future<bool> checkNotificationPermission() async {
    PermissionStatus permissionStatus = await NotificationPermissions.getNotificationPermissionStatus();

    if (permissionStatus == PermissionStatus.provisional || permissionStatus == PermissionStatus.unknown || permissionStatus == PermissionStatus.denied) {
      return false;
    } else {
      return true;
    }
  }
  ///Foreground messages
  ///
  ///To handle messages while your application is in the foreground, listen to the onMessage stream.
  void foreGroundMessageListener() {
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      print(message.data);
      RemoteNotification? notification = message.notification;
      AndroidNotification? android = message.notification?.android;
      if (notification != null && android != null && !kIsWeb) {
        print("show notification");
        print("show notification");

        flutterLocalNotificationsPlugin.show(
          notification.hashCode,
          notification.title,
          notification.body,
          NotificationDetails(
            android: AndroidNotificationDetails(
              channel.id,
              channel.name,
              channelDescription: channel.description,
              importance: Importance.max,
              priority: Priority.high,
              ticker: 'ticker',
              icon: "@mipmap/ic_launcher",
            ),
          ),
        );
      }
    });

    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      print('A new onMessageOpenedApp event was published!');

      //  Navigator.pushNamed(
      //    context,
      //    '/message',
      //    arguments: MessageArguments(message, true),
      //  );
    });
  }
}
final fcmUtils = FcmUtils();
