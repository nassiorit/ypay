class Fonts{
  static String SemiBold = "SemiBold";
  static String Bold = "Bold";
  static String Light = "Light";
  static String Regular = "Regular";
}