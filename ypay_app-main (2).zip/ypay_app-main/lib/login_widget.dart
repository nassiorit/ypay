import 'dart:async';

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

import 'fonts.dart';


class LoginWebView extends StatefulWidget {
  final String email;
  final String password;

  LoginWebView({required this.email, required this.password});

  @override
  _LoginWebViewState createState() => _LoginWebViewState();
}

class _LoginWebViewState extends State<LoginWebView> {
  final Completer<WebViewController> _controller = Completer<WebViewController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Login WebView')),
      body: WebView(
        initialUrl: 'https://ypay.co.il/main/index/login',
        javascriptMode: JavascriptMode.unrestricted,
        onWebViewCreated: (WebViewController webViewController) {
          _controller.complete(webViewController);
        },
        onPageFinished: (String url) async {
          if (url == 'https://ypay.co.il/main/index/login') {
            // Populate the email and password fields and submit the form
            await _controller.future.then((controller) {
              controller.evaluateJavascript('''
                document.querySelector("input[name='email']").value = "${widget.email}";
                document.querySelector("input[name='password']").value = "${widget.password}";
                document.querySelector("form").submit();
              ''');

               controller.evaluateJavascript('''
                document.documentElement.outerHTML.toString()
              ''').then((value){
                 if (value.contains("שגויים")) {
                   // Handle wrong password case
                   print("user name and password are invaild");
                   Navigator.pop(context); // Pop the WebView
                   _showLoginError();
                 }
               });
            });
            
          }
          
        },
      ),


      bottomNavigationBar: BottomNavigationBar(
       // onTap: onTabTapped,
     //   currentIndex: _currentIndex,
        items: [
          BottomNavigationBarItem(
            icon: new Icon(Icons.settings_applications_sharp),
            label: 'הגדרות',
          ),
          BottomNavigationBarItem(
            icon: new Icon(Icons.mail),
            label: 'Messages',
          ),
          BottomNavigationBarItem(
              icon: Icon(Icons.person),
              label: 'Profile'
          )
        ],
      ),
    );
  }
  void _showLoginError() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: AlertDialog(
            title: Text('שגיאת התחברות', style: TextStyle(fontFamily:Fonts.Bold,fontSize: 22,)),
            content: Text('שם משתמש או סיסמא אינם נכונים.', style: TextStyle(fontFamily:Fonts.Regular,fontSize: 18,)),
            actions: <Widget>[
              TextButton(
                child: Text('סגור', style: TextStyle(fontFamily:Fonts.Regular,fontSize: 18,)),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ],
          ),
        );
      },
    );
  }



}