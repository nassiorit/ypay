
import 'package:shared_preferences/shared_preferences.dart';

class OnBoardingHelper {
  static const String IS_FIRST_LAUNCH = 'isFirstLaunch';

  static Future<bool> isFirstLaunch() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getBool(IS_FIRST_LAUNCH) ?? true;
  }

  static Future<void> setFirstLaunchCompleted() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setBool(IS_FIRST_LAUNCH, false);
  }
}