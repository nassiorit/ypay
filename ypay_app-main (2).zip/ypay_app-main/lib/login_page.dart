import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_emoji/flutter_emoji.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart' as fss;
import 'package:local_auth/local_auth.dart';
import 'package:notification_permissions/notification_permissions.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import 'fcm_utils.dart';
import 'fonts.dart';
import 'home.dart';
import 'login_widget.dart';

class LoginPage extends StatefulWidget {

  bool isError;
  LoginPage({required this.isError});


  @override
  State<LoginPage> createState() => _LoginPageState();
}
enum _SupportState {
  unknown,
  supported,
  unsupported,
}

class _LoginPageState extends State<LoginPage> {

  TextEditingController _emailController = TextEditingController();
  TextEditingController _passwordController = TextEditingController();

  String email ="";
  bool isChecked = false;
  bool clickAddAccount = false;
  List<String> emails = [];


  final _storage = const fss.FlutterSecureStorage();

  final LocalAuthentication auth = LocalAuthentication();
  _SupportState _supportState = _SupportState.unknown;
  bool _canCheckBiometrics = false;

  void _navigateToLoginWebView(BuildContext context) {
    if (_emailController.text.isNotEmpty &&
        _passwordController.text.isNotEmpty) {

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (context) =>
              Home(
                email: _emailController.text,
                password: _passwordController.text,
                save: isChecked,
              ),
        ),
      );
    }
  }

  void _navigateToLoginWebViewAfterAuth(BuildContext context,String email,String password) {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) =>
            Home(
              email: email,
              password: password,
              save: isChecked,
            ),
      ),
    );
  }

  Future<void> _authenticate(BuildContext context,String email,String password) async {
    bool authenticated = false;
    try {
      authenticated = await auth.authenticate(
        localizedReason: 'התחברות מהירה',
        options: const AuthenticationOptions(
          stickyAuth: true,
        ),
      );
    } on PlatformException catch (e) {
      print(e);
      return;
    }
    if (authenticated){
      print("authenticated");
      _navigateToLoginWebViewAfterAuth(context,email,password);
    }else{
      print("not authenticated");
    }
  }


  Future<List<String>> getEmailList() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();

    // Returns the list of emails, or an empty list if there's no such key
    return prefs.getStringList('emailList') ?? [];
  }

  Future<void> initEmailList() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();

    // Returns the list of emails, or an empty list if there's no such key
    setState(() {
      emails = prefs.getStringList('emailList') ?? [];
    });
  }

  Future<void> saveEmailList(List<String> emails) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();

    // 'emailList' is the key we're using to store our list of emails
    await prefs.setStringList('emailList', emails);
  }



  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    NotificationPermissions.requestNotificationPermissions();
    initEmailList();
    print("init init");
    auth.isDeviceSupported().then((value){
      if(value){
        print("is supported");
        print(value);
        _checkBiometrics();
      }else{
        print("is supported false");
      }
    });
    if(widget.isError){
      print("is error");
  //    _showLoginError();
    }
  }

  Future<void> _checkBiometrics() async {
    late bool canCheckBiometrics;
    try {
      canCheckBiometrics = await auth.canCheckBiometrics;
      print(canCheckBiometrics);
    } on PlatformException catch (e) {
      canCheckBiometrics = false;
      print(e);
    }

    setState(() {
      _canCheckBiometrics = canCheckBiometrics;
    });
  }

  @override
  Widget build(BuildContext context) {

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        bottomNavigationBar: Padding(
          padding: const EdgeInsets.only(bottom: 24.0),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
            Visibility(
            visible: Platform.isAndroid,
              child: Text("אין לך חשבון?", style: TextStyle(fontFamily:Fonts.Regular,fontSize: 16,))),
              SizedBox(width: 4,),
              GestureDetector(
                onTap: (){
                  _launchURL("https://ypay.co.il/front/register");
                },
                child: Visibility(
                  visible: Platform.isAndroid,
                  child: Text("הצטרף אלינו בחינם!", style: TextStyle(color:Color.fromARGB(
                      255, 100, 59, 182),fontFamily:Fonts.Bold,fontSize: 16,)),
                ),
              ),
            ],
          ),
        ),
        body: Padding(
          padding: EdgeInsets.all(24),
          child: SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 56,),
                Container(
                    height: 26,
                    child: Center(child: Image.asset('images/ypay_logo.png'))),
                SizedBox(height: 36,),
                Row(
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(('ברוכים הבאים 👋️'), style: TextStyle(fontFamily:Fonts.Bold,fontSize: 20,)),
                        Text("הכנס אימייל וסיסמא להתחברות", style: TextStyle(fontFamily:Fonts.Regular,fontSize: 17,)),
                      ],
                    ),
                    Spacer(),
                    Visibility(
                      visible: emails.length > 0,
                      child: IconButton(
                        icon: Icon(clickAddAccount ? Icons.list : Icons.add),
                        onPressed: () {
                          setState(() {
                            clickAddAccount = !clickAddAccount;
                          });

                        },
                      ),
                    ),
                  ],
                ),
                  SizedBox(height: 32,),

                mainLoginWidget(),

              ],
            ),
          ),
        ),
      ),
    );
  }

  void _launchURL(String url) async {
    if (!await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication,)) {
      throw Exception('Could not launch');
    }
  }
  void removeEmailFromSP(String email) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();

    prefs.remove(email); // replace 'your_key' with the key of the string you want to remove
  }
  Future<String> getEmail() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String email = prefs.getString('email') ?? ''; // return empty string if email is null
    _emailController.text = email;

    return email;
  }
  fss.AndroidOptions _getAndroidOptions() => const fss.AndroidOptions(
    encryptedSharedPreferences: true,
    // sharedPreferencesName: 'Test2',
    // preferencesKeyPrefix: 'Test'
  );
  Future<String?> getPasswordByEmail(String email) async {
  //  SharedPreferences prefs = await SharedPreferences.getInstance();
 //   String password = prefs.getString(email) ?? ''; // return empty string if email is null
    final result =
    await _storage.read(key: email, aOptions: _getAndroidOptions());
    return result;
  }
  void _showLoginError() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: AlertDialog(
            title: Text('שגיאת התחברות', style: TextStyle(fontFamily:Fonts.Bold,fontSize: 22,)),
            content: Text('שם משתמש או סיסמא אינם נכונים.', style: TextStyle(fontFamily:Fonts.Regular,fontSize: 18,)),
            actions: <Widget>[
              TextButton(
                child: Text('סגור', style: TextStyle(fontFamily:Fonts.Regular,fontSize: 18,)),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ],
          ),
        );
      },
    );
  }

  Widget mainLoginWidget(){
    if((emails == null || emails.length > 0) && !clickAddAccount){
      return listAccount(emails);
    }else{
      return Column(
        children: [
          TextField(
            controller: _emailController,
            cursorColor: Color.fromARGB(255, 88, 161, 147) ,
            decoration: InputDecoration(
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(color: Colors.grey),
              ),
              labelText: 'אימייל',
            ),
            style: TextStyle(fontFamily: Fonts.Regular),
          ),
          SizedBox(height: 24),
          TextField(
            controller: _passwordController,
            decoration: InputDecoration(
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(color: Colors.grey),
              ),
              labelText: 'סיסמא',
            ),
            obscureText: true,
            style: TextStyle(fontFamily: Fonts.Regular),
          ),
          SizedBox(height: 24,),
          Visibility(visible:widget.isError,child: Text('שם משתמש או סיסמא אינם נכונים.', style: TextStyle(fontFamily:Fonts.Regular,fontSize: 14,color: Colors.red))),
          Visibility(
            visible: _canCheckBiometrics,
            child: GestureDetector(
              onTap: (){
                setState(() {
                  isChecked = !isChecked!;
                });
              },
              child: Row(
                children: [
                  Checkbox(
                    //  checkColor: Colors.red,
                    value: isChecked,
                    onChanged: (bool? value) {
                      setState(() {
                        isChecked = value!;
                      });
                    },
                  ),
                  Visibility(
                      visible: _canCheckBiometrics,
                      child: Text("שמור פרטי התחברות", style: TextStyle(fontFamily:Fonts.Regular,fontSize: 16)))
                ],
              ),
            ),
          ),
          Row(
            children: [
              Spacer(),
              GestureDetector(
                  onTap: (){
                    _launchURL("https://ypay.co.il/front/forgotpassword");
                  },
                  child: Text("שכחתי סיסמא", style: TextStyle(fontFamily:Fonts.Regular,fontSize: 16)))
            ],
          ),
          SizedBox(height: 24,),
          InkWell(
            child: Container(
                decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Color.fromARGB(255, 88, 161, 147).withOpacity(0.5),
                        spreadRadius: 3,
                        blurRadius: 20,
                        offset: Offset(0, 2), // changes position of shadow
                      ),
                    ],
                    shape: BoxShape.rectangle,
                    borderRadius: BorderRadius.circular(20),
                    gradient: LinearGradient(
                        begin: Alignment.topRight,
                        end: Alignment.bottomLeft,
                        colors: [
                          Color.fromARGB(255, 88, 161, 147),
                          Color.fromARGB(255, 88, 161, 147)
                        ])),
                height: 65,
                child: Center(
                    child: Text("התחבר",
                      style: TextStyle(
                          fontSize: 16,
                          color: Colors.white,
                          fontWeight: FontWeight.bold),
                    ))),
            onTap: () {
              _navigateToLoginWebView(context);
            },
          ),
        ],
      );
    }
  }
  Widget loginWithText(){
    return ListView.builder(
      itemCount: emails.length,
      itemBuilder: (context, index) {
        return ListTile(
          title: Text(emails[index]),
          trailing: IconButton(
            icon: Icon(Icons.delete),
            onPressed: () {
              setState(() {
                emails.removeAt(index);
              });
            },
          ),
        );
      },
    );
  }

  Widget listAccount(List<String> emails){
    print("emails");
    print(emails);
    return ListView.builder(
      shrinkWrap: true,
      itemCount: emails.length+1,
      physics: NeverScrollableScrollPhysics(),
      itemBuilder: (context, index) {
        if(index == emails.length){
          print("--------------------------------");
          return Row(
            children: [
              Spacer(),
              GestureDetector(
                  onTap: (){
                    setState(() {
                      clickAddAccount = true;
                    });
                  },
                  child: Padding(
                    padding: const EdgeInsets.only(top:1.0),
                    child: Text("התחבר עם חשבון אחר", style: TextStyle(fontFamily:Fonts.Regular,fontSize: 16)),
                  ))
            ],
          );
        }
        else{
          return Padding(
            padding: const EdgeInsets.only(bottom: 8.0),
            child: Container(
              decoration: BoxDecoration(
                border: Border.all(
                  color: Colors.grey,
                  width: 1.0, // You can set the width as needed.
                ),
                borderRadius: BorderRadius.circular(12.0),
              ),
              child: ListTile(
                title: Row(
                  //mainAxisSize: MainAxisSize.min,
                  children: [
                    GestureDetector(
                      onTap: (){
                        removeEmailFromSP(emails[index]);

                        setState(() {
                          emails.removeAt(index);
                        });

                        saveEmailList(emails);
                      },
                        child: Icon(Icons.remove,size: 20,)),
                    SizedBox(width: 12,),
                    Flexible(child: Text(emails[index],style: TextStyle(
                        fontSize: 15,
                        color: Colors.black,
                        fontFamily: Fonts.Regular))),
                  ],
                ),
                trailing: InkWell(
                  child: Container(
                      decoration: BoxDecoration(
                          boxShadow: [
                            BoxShadow(
                              color: Color.fromARGB(255, 88, 161, 147).withOpacity(0.5),
                              spreadRadius: 2,
                              blurRadius: 5,
                              offset: Offset(0, 1), // changes position of shadow
                            ),
                          ],
                          shape: BoxShape.rectangle,
                          borderRadius: BorderRadius.circular(20),
                          gradient: LinearGradient(
                              begin: Alignment.topRight,
                              end: Alignment.bottomLeft,
                              colors: [
                                Color.fromARGB(255, 88, 161, 147),
                                Color.fromARGB(255, 88, 161, 147)
                              ])),
                      height: 30,
                      width: 60,
                      child: Center(
                          child: Text("התחבר",
                            style: TextStyle(
                                fontSize: 10,
                                color: Colors.white,
                                fontWeight: FontWeight.bold),
                          ))),
                  onTap: () {
                    getPasswordByEmail(emails[index]).then((value){
                      _authenticate(context,emails[index],value!);
                    });

                  },
                ),
              ),
            ),
          );
        }
      },
    );
  }
}
