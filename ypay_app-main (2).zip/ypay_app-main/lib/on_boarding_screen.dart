import 'package:flutter/material.dart';
import 'package:flutter_native_splash/flutter_native_splash.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_swiper_null_safety/flutter_swiper_null_safety.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

import 'fonts.dart';
import 'login_page.dart';

class OnboardingScreen extends StatefulWidget {
  @override
  _OnboardingScreenState createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
 // final controller = PageController();
  final int totalPages = 3;
  int active = 1;
  int currentPage = 0;
  final controller = SwiperController();

  @override
  Widget build(BuildContext context) {
    FlutterNativeSplash.remove();

    return Directionality(
      textDirection: TextDirection.rtl,

      child: Scaffold(
        body: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 56,),

              Container(
                  height: 26,
                  child: Center(child: Image.asset('images/ypay_logo.png'))),
              Expanded(
                child: Swiper(
                  controller: controller,
                  itemCount: totalPages,
                  onIndexChanged: (index) {
                    setState(() {
                      currentPage = index;
                    });
                  },
                  itemBuilder: (BuildContext context, int index) {
                    return  Container(
                        child: Center(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Center(
                                child: Container(
                                  width: 300,
                                  height: 300,
                                  child: SvgPicture.asset(
                                    getImage(index),
                                  ),
                                ),
                              ),
                              Text(getTitle(index), style: TextStyle(fontFamily:Fonts.Bold,fontSize: 24,)),
                              Text(getSubTitle(index), style: TextStyle(fontFamily:Fonts.Regular,fontSize: 20,)),

                            ],
                          ),
                        ),
                      );
                  },
                ),
              ),
             // SizedBox(height: 20),
              SizedBox(height: 40),
              Padding(
                padding: const EdgeInsets.only(left: 24.0,right: 48.0),
                child: Row(
                  children: [
                    AnimatedSmoothIndicator(
                      activeIndex: currentPage,
                      count: totalPages,
                      effect: WormEffect(
                        dotHeight: 12,
                        dotWidth: 12,
                        dotColor: Colors.grey.withOpacity(0.7),
                        activeDotColor:  Color.fromARGB(255, 88, 161, 147),
                      ),
                    ),
                    Spacer(),
                    InkWell(
                      child: Container(
                          decoration: BoxDecoration(
                              boxShadow: [
                                BoxShadow(
                                  color:  Color.fromARGB(255, 88, 161, 147).withOpacity(0.5),
                                  spreadRadius: 3,
                                  blurRadius: 20,
                                  offset: Offset(0, 2), // changes position of shadow
                                ),
                              ],
                              shape: BoxShape.rectangle,
                              borderRadius: BorderRadius.circular(35),
                              gradient: LinearGradient(
                                  begin: Alignment.topRight,
                                  end: Alignment.bottomLeft,
                                  colors: [
                                    Color.fromARGB(255, 88, 161, 147),
                                    Color.fromARGB(255, 88, 161, 147)
                                  ])),
                          height: 70,
                          width: 70,
                          child: Center(
                              child:  Icon(currentPage == 2 ? Icons.check :Icons.navigate_next_rounded,size: 38,color: Colors.white,))),
                      onTap: () {
                        if (currentPage < (totalPages - 1)) {
                          controller.next(animation: true);
                        } else {
                          // navigate to home screen or any other screen
                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(
                              builder: (context) => LoginPage(isError: false,),
                            ),
                          );
                        }
                      },
                    ),
                  ],
                ),
              ),
             // SizedBox(height: 30),
            ],
          ),
        ),
      ),
    );
  }

  String getTitle(int index){
    if (index == 0){
      return "הפקת חשבוניות";

    }else if (index == 1){
      return "הפקת דו״חות";
    }
    return "גיבוי בענן";
  }

  String getSubTitle(int index){
    if (index == 0){
      return "התחילו להפיק חשבוניות כבר עכשיו בקלות ושמירה בענן.";

    }else if (index == 1){
      return "הפיקו דוחו״ת, חשבוניות, וקבלות במהירות ובלחיצת כפתור אחת!";
    }
    return "כלל הדוחות והמסמכים שתפיקו יגובו וישמרו בענן - הזמן שלכם יקר.";
  }

  String  getImage(int index){
    if (index == 0){
      return "images/on_board_one.svg";

    }else if (index == 1){
      return "images/on_board_two.svg";
    }
    return "images/on_board_three.svg";
  }
}
