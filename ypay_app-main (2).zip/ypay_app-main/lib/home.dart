
import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

import 'package:flutter_native_splash/flutter_native_splash.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart' as fss;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/platform_interface.dart';
import 'package:webview_flutter/webview_flutter.dart';


import 'fonts.dart';
import 'login_page.dart';

import 'package:http/http.dart' as http;

class Home extends StatefulWidget {
  late final bool save;
  late final String email;
  late final String password;

  Home({required this.email, required this.password,required this.save});

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  // Properties & Variables needed

  final _storage = const fss.FlutterSecureStorage();


  List<String> emails = [];

  final docs = [
    'הצעת מחיר',
    'הזמנת עבודה',
    'חשבונית עסקה',
    'תעודת משלוח',
    'תעודת החזרה',
    'חשבונית מס',
    'חשבונית מס זיכוי',
    'חשבונית מס קבלה',
    'קבלה',
  ];

  final docs_urls = [
    'https://ypay.co.il/main/newdocument/income?type=price_quote',
    'https://ypay.co.il/main/newdocument/income?type=work_order',
    'https://ypay.co.il/main/newdocument/income?type=deal_invoice',
    'https://ypay.co.il/main/newdocument/income?type=consignment_note',
    'https://ypay.co.il/main/newdocument/income?type=certificate_return',

    'https://ypay.co.il/main/newdocument/income?type=tax_invoice',
    'https://ypay.co.il/main/newdocument/income?type=credit_invoice',
    'https://ypay.co.il/main/newdocument/income?type=invoice_receipt',

    'https://ypay.co.il/main/newdocument/income?type=receipt',
  ];

  final simple_docs = [
    'הצעת מחיר',
    'הזמנת עבודה',
    'חשבונית עסקה',
    'תעודת משלוח',
    'תעודת החזרה',
    'קבלה',
  ];

  final simple_docs_urls = [
    'https://ypay.co.il/main/newdocument/income?type=price_quote',
    'https://ypay.co.il/main/newdocument/income?type=work_order',
    'https://ypay.co.il/main/newdocument/income?type=deal_invoice',
    'https://ypay.co.il/main/newdocument/income?type=consignment_note',
    'https://ypay.co.il/main/newdocument/income?type=certificate_return',

    'https://ypay.co.il/main/newdocument/income?type=receipt',
  ];

  final report_items = [
    'ספר הכנסות והוצאות',
    'ספר תקבולים תשלומים',
    'כרטסת חשבונות',
    'דוח רווח והפסד',
    'רווח והפסד לפי חודש',
    'לקוחות לפי חודש',
    'ספקים לפי חודש',
    'הכנסות לפי לקוחות',
    'דו״ח מכירות לפריטים',
    'הפרשי שומה',
  ];

  final report_urls = [
    'https://ypay.co.il/main/report/transactions',
    'https://ypay.co.il/main/report/payments',
    'https://ypay.co.il/main/report/index',
    'https://ypay.co.il/main/report/balance',
    'https://ypay.co.il/main/report/annualBalance',
    'https://ypay.co.il/main/report/annualCustomers',
    'https://ypay.co.il/main/report/annualSuppliers',
    'https://ypay.co.il/main/report/customerIncome',
    'https://ypay.co.il/main/report/items',
    'https://ypay.co.il/main/report/assessment',
  ];

  final simple_report_items = [
    'ספר תקבולים תשלומים',
    'כרטסת חשבונות',
    'דוח רווח והפסד',
    'רווח והפסד לפי חודש',
    'לקוחות לפי חודש',
    'ספקים לפי חודש',
    'הפרשי שומה',
  ];

  final simple_report_urls = [
    'https://ypay.co.il/main/report/payments',
    'https://ypay.co.il/main/report/index',
    'https://ypay.co.il/main/report/balance',
    'https://ypay.co.il/main/report/annualBalance',
    'https://ypay.co.il/main/report/annualCustomers',
    'https://ypay.co.il/main/report/annualSuppliers',
    'https://ypay.co.il/main/report/assessment',
  ];

  String currentUrl = "https://ypay.co.il/main/index/login";

  final GlobalKey webViewKey = GlobalKey();

  InAppWebViewController? webViewController;

  InAppWebViewGroupOptions options = InAppWebViewGroupOptions(
      crossPlatform: InAppWebViewOptions(
        useShouldOverrideUrlLoading: true,
        mediaPlaybackRequiresUserGesture: false,
      ),
      android: AndroidInAppWebViewOptions(
        useHybridComposition: true,
      ),
      ios: IOSInAppWebViewOptions(
        allowsInlineMediaPlayback: true,
      ));


  final PageStorageBucket bucket = PageStorageBucket();

  final Completer<WebViewController> _controller = Completer<WebViewController>();

  bool is_simple = true;

  double progress = 0;

  void saveAccount(String email,String password){
    saveEmailInList(email);
    savePassword(email,password);
  }

  fss.AndroidOptions _getAndroidOptions() => const fss.AndroidOptions(
    encryptedSharedPreferences: true,
    // sharedPreferencesName: 'Test2',
    // preferencesKeyPrefix: 'Test'
  );

  void savePassword(String email,String passw) async {
    await _storage.write(
      key: email,
      value: passw,
      aOptions: _getAndroidOptions(),
    );
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.setString(email, passw);
  }

  Future<void> saveEmailInList(String email) async {
    print("----------------need save");
    List<String> emails = await getEmailList();
    if(!emails.contains(email)){
      print("----------------one save");
      emails.add(email);
      final SharedPreferences prefs = await SharedPreferences.getInstance();

      // 'emailList' is the key we're using to store our list of emails
      await prefs.setStringList('emailList', emails);
    }else{
      print("----------------not save");
    }
  }

  Future<void> saveEmailList(List<String> emails) async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();

    // 'emailList' is the key we're using to store our list of emails
    await prefs.setStringList('emailList', emails);
  }

  Future<List<String>> getEmailList() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();

    // Returns the list of emails, or an empty list if there's no such key
    return prefs.getStringList('emailList') ?? [];
  }


  Future<void> sendPostRequest() async {
    final String apiUrl = 'https://ypay.co.il/api/v1/user'; // replace with your API url
    final String authToken = 'a1e9a4f3cc61bbacef2b832eaae772f53ee4f23be85880b6380a79c5ce459e28'; // replace with your auth token

    //String email =await getEmail();

    final response = await http.post(
      Uri.parse(apiUrl),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
        'Authorization': 'Bearer $authToken', // replace with your auth type and token
      },
      body: jsonEncode(<String, String>{
        'mail': widget.email, // replace with your email
      }),
    );

    if (response.statusCode == 200) {
      Map<String, dynamic> responseJson = jsonDecode(response.body);
      print('User type: ${responseJson['user_type']}');
      if(responseJson.containsKey('user_type')){
        String user_type = responseJson['user_type'];
        if(user_type.contains("npo") || user_type.contains("exempt")){
          setState(() {
            is_simple = true;
          });
        }
        else{
          setState(() {
            is_simple = false;
          });
        }
      }
    } else {
      print('Request failed with status: ${response.statusCode}.');
    }
  }


  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    initEmailList();
    sendPostRequest();
  }

  _launchURL(String url) async {
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }
  Future<void> launchWeb(String str) async {
    if (!await launchUrl(Uri.parse(str), mode: LaunchMode.externalApplication,)) {
      throw Exception('Could not launch');
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle(
        statusBarColor: Color.fromARGB(255, 88, 161, 147), // Make status bar transparent
      ),

      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          extendBodyBehindAppBar: true, // Extend body behind the app bar
          body: SafeArea(
            child: InAppWebView(
              key: webViewKey,
              initialUrlRequest: URLRequest(url: Uri.parse(currentUrl)),
              initialOptions: options,
              onWebViewCreated: (controller) {
                webViewController = controller;
              },
              onLoadStart: (controller, url) async {
                print("onLoadStart");

                if(url.toString().contains(".pdf")){
                  print("true");
                  await launchUrl(Uri.parse(url.toString()), mode: LaunchMode.externalApplication);
                }
                setState(() {
                  this.currentUrl = url.toString();
                });
              },
              androidOnPermissionRequest: (controller, origin, resources) async {
                return PermissionRequestResponse(
                    resources: resources,
                    action: PermissionRequestResponseAction.GRANT);
              },
              shouldOverrideUrlLoading: (controller, navigationAction) async {
                print("shouldOverrideUrlLoading");

                var uri = navigationAction.request.url!;

                if (uri.toString().contains("shop")) {
                  return NavigationActionPolicy.CANCEL;
                }

                print("uri");
                print(uri);
                if(uri.toString().contains(".pdf")){
                  print("true");
                  await launchUrl(Uri.parse(uri.toString()), mode: LaunchMode.externalApplication);

                }
                else if(uri.toString().contains('/index/logout')){
                  clearCache(false);
                }
                if (![ "http", "https", "file", "chrome",
                  "data", "javascript", "about"].contains(uri.scheme)) {
                  print("!!!!!");

                  if (await canLaunch(currentUrl)) {
                    // Launch the App
                    await launch(
                      currentUrl,
                    );
                    // and cancel the request
                    return NavigationActionPolicy.CANCEL;
                  }
                }

                return NavigationActionPolicy.ALLOW;
              },
              onLoadStop: (controller, url) async {
                print("onLoadStop");

                setState(() {
                  this.currentUrl = url.toString();
                });
                print("onLoadStop");

                FlutterNativeSplash.remove();
                if (url.toString().contains('/index/login')) {
                  print("url good");

                  // Populate the email and password fields and submit the form
                  if(widget.email.isNotEmpty && widget.password.isNotEmpty){
                    print("not empty");

                    await controller.evaluateJavascript(source: '''
            document.querySelector("input[name='email']").value = "${widget.email}";
            document.querySelector("input[name='password']").value = "${widget.password}";
            document.querySelector("form").submit();
          ''');
    var htmlContent = await controller.evaluateJavascript(source: '''
            document.documentElement.outerHTML.toString()
          ''');
                    if (htmlContent.contains("שגויים")) {
                      // Handle wrong password case
                      print("user name and password are invaild");
                     // Pop the WebView
                    //  _showLoginError();
                      print("not save account");
                      removeEmailFromSP(widget.email);
                      clearCache(true);
                    }else{
                      if(widget.save){
                        print("save account");
                        saveAccount(widget.email, widget.password);
                      }
                    }

                  }
                  else{
                    print("empty");

                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (context) => LoginPage(isError: false,),
                      ),
                    );
                  }
                }

                else if (url.toString().contains('index/business')){
                  sendPostRequest();
                  print(url);
                }

                else if(url.toString().contains('/index/logout')){
                  widget.password = "";
                  widget.email = "";
                  clearCache(false);
                }

              },
              onLoadError: (controller, url, code, message) {

              },
              onProgressChanged: (controller, progress) {
                if (progress == 100) {

                }
                setState(() {
                  this.progress = progress / 100;
                });
              },
              onUpdateVisitedHistory: (controller, url, androidIsReload) {
                setState(() {
                  this.currentUrl = url.toString();

                });
              },
              onConsoleMessage: (controller, consoleMessage) {
                print("onConsoleMessage");
                print(consoleMessage);
              },
            ),


          ),
          floatingActionButton: FloatingActionButton(
            backgroundColor: Color.fromARGB(255, 88, 161, 147),
            child: Icon(Icons.add),
            onPressed: () {
              showMenuAdd();
            },
          ),
          floatingActionButtonLocation: FloatingActionButtonLocation.endDocked,
          bottomNavigationBar: BottomAppBar(
            shape: CircularNotchedRectangle(),
            notchMargin: 10,
            child: Container(
              height: 80,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[

                  MaterialButton(
                    minWidth: Platform.isAndroid ? 50 : 40,
                    onPressed: () {
                      setState(() {
                        currentUrl = "https://ypay.co.il/main/index/business";
                        webViewController?.loadUrl(urlRequest: URLRequest(url: Uri.parse(currentUrl)));

                      });
                    },
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Icon(
                          Icons.settings_applications_sharp,
                          color: Colors.grey,
                        ),
                        Text(
                          'הגדרות',
                          style: TextStyle(
                            color:Colors.grey,
                            fontFamily:Fonts.Regular,
                            fontSize: 16,
                          ),
                        ),
                      ],
                    ),
                  ),

                  /*Visibility(
                    visible: Platform.isAndroid,
                    child: MaterialButton(
                      minWidth: 50,
                      onPressed: () {
                        setState(() {
                          currentUrl = "https://ypay.co.il/main/shop";

                          webViewController?.loadUrl(urlRequest: URLRequest(url: Uri.parse(currentUrl)));

                        });
                      },
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Icon(
                            Icons.store,
                            color: Colors.grey,
                          ),
                          Text(
                            'חנות',
                            style: TextStyle(
                              color:Colors.grey,
                              fontFamily:Fonts.Regular,
                              fontSize: 16,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),*/

                  MaterialButton(
                    minWidth: 40,
                    onPressed: () {
                      showMenuRepoerts();

                    },
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Icon(
                          Icons.table_chart_outlined,
                          color: Colors.grey,
                        ),
                        Text(
                          'דוחות',
                          style: TextStyle(
                            color:Colors.grey,
                            fontFamily:Fonts.Regular,
                            fontSize: 16,
                          ),
                        ),
                      ],
                    ),
                  ),

                  MaterialButton(
                    minWidth: Platform.isAndroid ? 50 : 40,
                    onPressed: () {
                      setState(() {
                        currentUrl = "https://ypay.co.il/main/albumsupload/index";
                        webViewController?.loadUrl(urlRequest: URLRequest(url: Uri.parse(currentUrl)));

                      });
                    },
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Icon(
                          Icons.camera_alt,
                          color: Colors.grey,
                        ),
                        Text(
                          'העלאה',
                          style: TextStyle(
                            color:Colors.grey,
                            fontFamily:Fonts.Regular,
                            fontSize: 16,
                          ),
                        ),
                      ],
                    ),
                  ),


                Platform.isAndroid ? MaterialButton(
                  minWidth: 80,
                  onPressed: () {
                  },
                  child: Container(
                  ),
                ) : Container(),



                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void showMenuAdd(){

    showModalBottomSheet(
      shape: RoundedRectangleBorder(  // set rounded corner
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(25),  // set the radius
        ),
      ),
      context: context,
      isScrollControlled: true,
      builder: (BuildContext context) {
        return Container(
          height: MediaQuery.of(context).size.height * 0.8,  // 90% of screen height
          child: Directionality(
            textDirection: TextDirection.rtl,
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Stack(
                      children:[
                        Align(
                          alignment: Alignment.center,
                          child: Container(
                            padding: EdgeInsets.all(16.0),

                            child: Text(
                              'הפקת מסמכים',
                              style: TextStyle(
                                fontSize: 20.0,
                                fontFamily:Fonts.Bold,
                              ),
                            ),
                          ),
                        ),
                        Align(
                          alignment: Alignment.topLeft,
                          child: IconButton(
                            icon: Icon(Icons.close),
                            onPressed: () {
                              // Add your code here to handle the close action.
                              Navigator.pop(context);

                              print('Close button tapped');
                            },
                          ),
                        ),
                      ],
                    ),
                  ),

                  ListView.builder(
                    shrinkWrap: true,
                    itemCount: is_simple ? simple_docs.length : docs.length,
                    itemBuilder: (context, index) {
                      return ListTile(
                        title: Text(is_simple ? simple_docs[index] : docs[index] ,style: TextStyle(
                          //color:Colors.grey,
                          fontFamily:Fonts.Regular,
                          fontSize: 16,
                        ),),
                        onTap: () {
                          print('URL: ${is_simple ? simple_docs_urls[index] : docs_urls[index]}');

                          setState(() {
                            currentUrl = is_simple ? simple_docs_urls[index] : docs_urls[index];
                            webViewController?.loadUrl(urlRequest: URLRequest(url: Uri.parse(is_simple ? simple_docs_urls[index] : docs_urls[index])));
                          });
                          Navigator.pop(context);
                        },
                      );
                    },
                  ),
                ],
              ),
            ),
          )
        );
      },
    );
  }

  void showMenuRepoerts(){

    showModalBottomSheet(
      shape: RoundedRectangleBorder(  // set rounded corner
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(25),  // set the radius
        ),
      ),
      context: context,
      isScrollControlled: true,
      builder: (BuildContext context) {
        return Container(
            height: MediaQuery.of(context).size.height * 0.8,  // 90% of screen height
            child: Directionality(
              textDirection: TextDirection.rtl,
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Stack(
                        children:[
                          Align(
                            alignment: Alignment.center,
                            child: Container(
                              padding: EdgeInsets.all(16.0),

                              child: Text(
                                'דוחו״ת',
                                style: TextStyle(
                                  fontSize: 20.0,
                                  fontFamily:Fonts.Bold,
                                ),
                              ),
                            ),
                          ),
                          Align(
                            alignment: Alignment.topLeft,
                            child: IconButton(
                              icon: Icon(Icons.close),
                              onPressed: () {
                                // Add your code here to handle the close action.
                                Navigator.pop(context);

                                print('Close button tapped');
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                    ListView.builder(
                      shrinkWrap: true,
                      itemCount: is_simple ? simple_report_items.length : report_items.length,
                      itemBuilder: (context, index) {
                        return ListTile(
                          title: Text(is_simple ? simple_report_items[index] : report_items[index] ,style: TextStyle(
                            //color:Colors.grey,
                            fontFamily:Fonts.Regular,
                            fontSize: 16,
                          ),),
                          onTap: () {
                            print('URL: ${is_simple ? simple_report_urls[index] : report_urls[index]}');

                            setState(() {
                              currentUrl = is_simple ? simple_report_urls[index] : report_urls[index];
                              webViewController?.loadUrl(urlRequest: URLRequest(url: Uri.parse(is_simple ? simple_report_urls[index] : report_urls[index])));

                            });
                            Navigator.pop(context);
                          },
                        );
                      },
                    ),
                  ],
                ),
              ),
            )
        );
      },
    );
  }

  Future<String> getEmail() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String email = prefs.getString('email') ?? ''; // return empty string if email is null
    return email;
  }

  Future<void> initEmailList() async {
    final SharedPreferences prefs = await SharedPreferences.getInstance();

    // Returns the list of emails, or an empty list if there's no such key
    setState(() {
      emails = prefs.getStringList('emailList') ?? [];
    });
  }

  void removeEmailFromSP(String email) async {
    emails.remove(email);
    saveEmailList(emails);

    final SharedPreferences prefs = await SharedPreferences.getInstance();

    prefs.remove(email).then((value){

      print("account delete: ");
      print(value);
    }); // replace 'your_key' with the key of the string you want to remove
  }

  void clearCache(bool isError) async {
    await webViewController!.clearCache();
    print('Cache cleared!');
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => LoginPage(isError: isError,),
      ),
    );
  }
}