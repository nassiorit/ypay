package il.co.ypay.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
